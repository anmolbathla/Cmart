export class Staticdata {
  static category = "";
  static product = "";
  static useruid = "";
  static username = "";
}

export default Staticdata;
